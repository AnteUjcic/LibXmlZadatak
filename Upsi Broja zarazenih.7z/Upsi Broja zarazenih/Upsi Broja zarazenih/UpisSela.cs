﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Upsi_Broja_zarazenih
{
    public partial class UpisSela : Form
    {
        List<Selo> upisKList = new List<Selo>();
        public UpisSela()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnUpisSela_Click(object sender, EventArgs e)
        {

        }

        private void txtUpisSela_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIDSela_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
